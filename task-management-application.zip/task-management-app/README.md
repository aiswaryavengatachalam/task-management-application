# Task Management Application

A responsive full-stack task management web application.

## Features
- User registration and login
- Authentication and authorization
- Create, read, update and delete tasks
- Task status tracking
- Responsive design for desktop and mobile
- REST API using Express.js

## Technologies
HTML, CSS, JavaScript, Node.js and Express.js.

## Run locally
1. Install Node.js.
2. Open the project folder in terminal.
3. Run `npm install`.
4. Run `npm start`.
5. Open `http://localhost:3000`.

## GitHub Submission
Upload this complete folder to a public GitHub repository named `task-management-application`.
