let registerMode=false;
let token=localStorage.getItem("token");

const authSection=document.getElementById("authSection");
const appSection=document.getElementById("appSection");
const authTitle=document.getElementById("authTitle");
const authBtn=document.getElementById("authBtn");
const toggleAuth=document.getElementById("toggleAuth");
const nameInput=document.getElementById("name");
const message=document.getElementById("authMessage");

function updateAuthUI(){
  document.querySelector(".registerOnly").style.display=registerMode?"block":"none";
  authTitle.textContent=registerMode?"Register":"Login";
  authBtn.textContent=registerMode?"Register":"Login";
  toggleAuth.textContent=registerMode?"Already have an account? Login":"Create an account";
}
toggleAuth.onclick=()=>{registerMode=!registerMode;updateAuthUI()};

authBtn.onclick=async()=>{
  const endpoint=registerMode?"/api/auth/register":"/api/auth/login";
  const body={email:email.value,password:password.value};
  if(registerMode) body.name=nameInput.value;
  const res=await fetch(endpoint,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
  const data=await res.json();
  if(!res.ok){message.textContent=data.message;return}
  if(registerMode){registerMode=false;updateAuthUI();message.textContent="Registration successful. Please login."}
  else{token=data.token;localStorage.setItem("token",token);showApp()}
};

function showApp(){authSection.classList.add("hidden");appSection.classList.remove("hidden");loadTasks()}
function showLogin(){authSection.classList.remove("hidden");appSection.classList.add("hidden")}

document.getElementById("logoutBtn").onclick=()=>{localStorage.removeItem("token");token=null;showLogin()};

async function loadTasks(){
 const res=await fetch("/api/tasks",{headers:{Authorization:"Bearer "+token}});
 if(res.status===401){showLogin();return}
 const tasks=await res.json();
 const box=document.getElementById("tasks");
 box.innerHTML=tasks.length?"":"<p>No tasks yet.</p>";
 tasks.forEach(t=>{
   const div=document.createElement("div");div.className="task";
   div.innerHTML=`<h3>${escapeHtml(t.title)}</h3><p>${escapeHtml(t.description)}</p><small>Status: ${escapeHtml(t.status)}</small><br>
   <button class="edit" onclick="editTask('${t.id}')">Update</button>
   <button class="danger" onclick="deleteTask('${t.id}')">Delete</button>`;
   box.appendChild(div);
 });
}
document.getElementById("addTaskBtn").onclick=async()=>{
 const title=document.getElementById("taskTitle").value.trim();
 const description=document.getElementById("taskDescription").value.trim();
 const status=document.getElementById("taskStatus").value;
 if(!title)return alert("Enter a task title");
 await fetch("/api/tasks",{method:"POST",headers:{"Content-Type":"application/json",Authorization:"Bearer "+token},body:JSON.stringify({title,description,status})});
 document.getElementById("taskTitle").value="";document.getElementById("taskDescription").value="";loadTasks();
};
async function deleteTask(id){if(!confirm("Delete this task?"))return;await fetch("/api/tasks/"+id,{method:"DELETE",headers:{Authorization:"Bearer "+token}});loadTasks()}
async function editTask(id){
 const title=prompt("New task title"); if(!title)return;
 const status=prompt("Status: Pending / In Progress / Completed","Completed");
 await fetch("/api/tasks/"+id,{method:"PUT",headers:{"Content-Type":"application/json",Authorization:"Bearer "+token},body:JSON.stringify({title,status})});
 loadTasks();
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
updateAuthUI(); if(token)showApp(); else showLogin();
