const express=require("express");
const crypto=require("crypto");
const path=require("path");
const app=express();
const PORT=process.env.PORT||3000;

app.use(express.json());
app.use(express.static(path.join(__dirname,"public")));

const users=[];
const tasks=[];
const sessions=new Map();

function hash(password){return crypto.createHash("sha256").update(password).digest("hex")}
function auth(req,res,next){
 const token=(req.headers.authorization||"").replace("Bearer ","");
 const userId=sessions.get(token);
 if(!userId)return res.status(401).json({message:"Please login"});
 req.userId=userId;next();
}

app.post("/api/auth/register",(req,res)=>{
 const {name,email,password}=req.body;
 if(!name||!email||!password)return res.status(400).json({message:"All fields are required"});
 if(users.some(u=>u.email===email))return res.status(409).json({message:"Email already registered"});
 users.push({id:crypto.randomUUID(),name,email,password:hash(password)});
 res.status(201).json({message:"Registered successfully"});
});

app.post("/api/auth/login",(req,res)=>{
 const {email,password}=req.body;
 const user=users.find(u=>u.email===email&&u.password===hash(password));
 if(!user)return res.status(401).json({message:"Invalid email or password"});
 const token=crypto.randomUUID();sessions.set(token,user.id);
 res.json({token});
});

app.get("/api/tasks",auth,(req,res)=>res.json(tasks.filter(t=>t.userId===req.userId)));

app.post("/api/tasks",auth,(req,res)=>{
 const {title,description,status="Pending"}=req.body;
 if(!title)return res.status(400).json({message:"Title required"});
 const task={id:crypto.randomUUID(),userId:req.userId,title,description,status,createdAt:new Date().toISOString()};
 tasks.push(task);res.status(201).json(task);
});

app.put("/api/tasks/:id",auth,(req,res)=>{
 const task=tasks.find(t=>t.id===req.params.id&&t.userId===req.userId);
 if(!task)return res.status(404).json({message:"Task not found"});
 Object.assign(task,{title:req.body.title||task.title,description:req.body.description??task.description,status:req.body.status||task.status});
 res.json(task);
});

app.delete("/api/tasks/:id",auth,(req,res)=>{
 const i=tasks.findIndex(t=>t.id===req.params.id&&t.userId===req.userId);
 if(i<0)return res.status(404).json({message:"Task not found"});
 tasks.splice(i,1);res.json({message:"Task deleted"});
});

app.listen(PORT,()=>console.log(`Task Manager running on http://localhost:${PORT}`));
